from turtle import Turtle, Screen, colormode, penup
from random import choice, randint

# def random_color():
#     red = randint(0, 255)
#     green = randint(0, 255)
#     blue = randint(0, 255)
#     color = (red, green, blue)
#     return color
#

# # def shapes(side):
# #     angel = 360/side
# #     for square in range(side):
# #         the_best_turtle.forward(100)
# #         the_best_turtle.left(angel)
# #
# # for draw in range(3, 10):
# #     the_best_turtle.color(choice(colours))
# #     shapes(draw)
# #
# def draw_spirograph(size_of_gap):
#     for draw in range(int(360 / size_of_gap)):
#         the_best_turtle.color(random_color())
#         the_best_turtle.circle(100)
#         the_best_turtle.setheading(the_best_turtle.heading() + size_of_gap)
#
#
# draw_spirograph(5)




# import colorgram
#
# rgb_colors = []
# colors = colorgram.extract('image.jpg', 30)
# for color in colors:
#     r = color.rgb.r
#     g = color.rgb.g
#     b = color.rgb.b
#     new_color = (r, g, b)
#     rgb_colors.append(new_color)
# print(rgb_colors)

the_best_turtle = Turtle()
colormode(255)
color_list = [(249, 228, 17), (213, 13, 9), (198, 12, 35), (231, 228, 5), (197, 69, 20), (33, 90, 188),
              (43, 212, 71),(234, 148, 40), (33, 30, 152), (16, 22, 55), (66, 9, 49), (244, 39, 149),
              (65, 202, 229), (14, 205, 222), (63, 21, 10), (224, 19, 111), (229, 165, 8), (15, 154, 22),
              (245, 58, 16), (98, 75, 9), (248, 11, 9), (222, 140, 203), (68, 240, 161), (10, 97, 62),
              (5, 38, 33), (68, 219, 155)]

the_best_turtle.speed("fastest")
the_best_turtle.penup()
the_best_turtle.hideturtle()
the_best_turtle.setheading(225)
the_best_turtle.forward(300)
the_best_turtle.setheading(0)
number_of_dots = 100
for dot_count in range(1, number_of_dots + 1):
    the_best_turtle.dot(20, choice(color_list))
    the_best_turtle.forward(50)
    if dot_count % 10 == 0:
        the_best_turtle.setheading(90)
        the_best_turtle.forward(50)
        the_best_turtle.setheading(180)
        the_best_turtle.forward(500)
        the_best_turtle.setheading(0)
screen = Screen()
screen.exitonclick()