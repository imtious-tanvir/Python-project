import random
from turtle import Turtle, Screen




# def move_forwards():
#     the_best_turtle.forward(10)
#
#
# def move_backwards():
#     the_best_turtle.backward(10)
#
#
# def turn_right():
#     the_best_turtle.setheading(the_best_turtle.heading() + 10)
#
#
# def turn_left():
#     the_best_turtle.setheading(the_best_turtle.heading() - 10)
#
#
# def clear():
#     the_best_turtle.clear()
#     the_best_turtle.penup()
#     the_best_turtle.home()
#     the_best_turtle.pendown()
#
#
# screen.listen()
# screen.onkey(move_forwards, 'f')
# screen.onkey(move_backwards, 'b')
# screen.onkey(turn_right, 'r')
# screen.onkey(turn_left, 'l')
# screen.onkey(clear, 'c')
screen = Screen()
screen.setup(width=500, height=400)
user_guess = screen.textinput(title="Make your bet", prompt="Which turtle will win the race? Enter a color: ")
colors = ["red", "orange", "black", "green", "blue", "purple"]
y_positions = [-100, -60, -20, 20, 60, 100]
all_turtles = []



for turtle_index in range(6):
    new_turtle = Turtle(shape="turtle")
    new_turtle.color(colors[turtle_index])
    new_turtle.penup()
    new_turtle.goto(x=-230, y=y_positions[turtle_index])
    all_turtles.append(new_turtle)

race_goes = False
if user_guess:
    race_goes = True


while race_goes:
    for turtle in all_turtles:
        if turtle.xcor() > 230:
            race_goes = False
            winner = turtle.pencolor()
            if winner == user_guess:
                print(f"You've won! The {winner} turtle is the winner!")
            else:
                print(f"You've lost! The {winner} turtle is the winner!")
        random_distance = random.randint(0, 10)
        turtle.forward(random_distance)

screen.exitonclick()