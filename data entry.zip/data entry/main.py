from bs4 import BeautifulSoup
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

url = "https://appbrewery.github.io/Zillow-Clone/"
google_sheet_link = 'https://docs.google.com/forms/d/e/1FAIpQLSfKV6PcSqUWBgA1_IpjLJVSo3TNmvPMD_8hL9WZEvvXkV8N_w/viewform'


response = requests.get(url=url)
soup = BeautifulSoup(response.text, 'html.parser')

property_cards = soup.find_all('div', class_='StyledPropertyCardDataWrapper')


links = []
prices = []
addresses = []


for card in property_cards:
    link_tag = card.find('a', href=True)
    if link_tag:
        links.append(link_tag['href'])

    price_tag = card.find('span', class_='PropertyCardWrapper__StyledPriceLine')
    if price_tag:
        price = price_tag.get_text(strip=True).replace('+/mo', '').replace('/mo', '').split('+')[0]
        prices.append(price)

    address_tag = card.find('address')
    if address_tag:
        address = address_tag.get_text(strip=True).replace('\n', ' ').replace('  ', ' ').replace('| ', ' ')
        addresses.append(address)


print("Links:", links)
print("Prices:", prices)
print("Addresses:", addresses)


chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("detach", True)
driver = webdriver.Chrome(options=chrome_options)


for n in range(len(links)):
    try:
        # Open the Google Form
        driver.get(google_sheet_link)
        time.sleep(2)


        address_response = driver.find_element(
            By.XPATH, '//*[@id="mG61Hd"]/div[2]/div/div[2]/div[1]/div/div/div[2]/div/div[1]/div/div[1]/input'
        )
        price_response = driver.find_element(
            By.XPATH, '//*[@id="mG61Hd"]/div[2]/div/div[2]/div[2]/div/div/div[2]/div/div[1]/div/div[1]/input'
        )
        link_response = driver.find_element(
            By.XPATH, '//*[@id="mG61Hd"]/div[2]/div/div[2]/div[3]/div/div/div[2]/div/div[1]/div/div[1]/input'
        )
        submit_button = driver.find_element(
            By.XPATH, '//*[@id="mG61Hd"]/div[2]/div/div[3]/div[1]/div[1]/div/span/span'
        )


        address_response.send_keys(addresses[n])
        price_response.send_keys(prices[n])
        link_response.send_keys(links[n])


        submit_button.click()
        time.sleep(2)
    except Exception as e:
        print(f"Error submitting form for property {n + 1}: {e}")


driver.quit()