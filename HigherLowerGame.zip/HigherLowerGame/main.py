#display logo from art, import data from game data, import random module
from art import logo, vs
from game_data import data
import random
import os
import platform


#fatch data from game_data
def fatch_data(data):
    name = data['name']
    description = data['description']
    country = data['country']
    return f'{name}, a {description}, from {country}'

#check answer
def check_answer(guess, follower_a, follower_b):
    if follower_a > follower_b:
        return guess == 'a'
    else:
        return guess == 'b'

def clear_screen():
    if platform.system() == "Windows":
        os.system('cls')
    else:
        os.system('clear')
#print logo
print(logo)

score = 0
game_continue = True
data_b = random.choice(data)
while game_continue:
    #data genarate in a random process
    data_a = data_b
    data_b = random.choice(data)
    if data_a == data_b:
        data_b = random.choice(data)

    print(f'Compare A: {fatch_data(data_a)}.')
    print(vs)
    print(f'Compare B: {fatch_data(data_b)}.')

    #ask user for a guess
    guess = input("Who has more followers? Type 'A' or 'B': ").lower()

    #check user is correct or not
    follower_a = data_a['follower_count']
    follower_b = data_b['follower_count']
    is_correct = check_answer(guess, follower_a, follower_b)
    clear_screen()

    if is_correct:
        score += 1
        print(f"You are right! Current score: {score}")
    else:
        game_continue = False
        print(f"Sorry, that's wrong. Final score: {score}")